# Snake Antivenom Predictor — South Asia (educational decision-support prototype)

React + Vite frontend, Express API, and a **trained transfer-learning CNN** (EfficientNet-B0 -> ONNX, runs in the browser via onnxruntime-web).

**Not a medical device.** Antivenom decisions must follow bedside examination, the 20-minute whole-blood clotting test (20WBCT) and the national protocol.

## Run
```
npm install          # .npmrc sets legacy-peer-deps
npm run dev          # http://localhost:3000
npm run build && npm start
npm test             # 25 unit + 17 regression + 10 CNN tests
npm run qa:photos    # runs the model on the 8 bundled photos (independent of the training data)
```

## The model (what is real and what is not)
- Trained on 1,780 web-scraped photos (dataset: arjun921/Indian-Snakes-Dataset) of 13 species; 20% held out (duplicate-grouped) as a test set.
- **Held-out test (356 photos): 80.1% species accuracy, macro-F1 0.80, 91.6% 3-class triage (viper/elapid/harmless).**
- Safety policy: abstain when unsure; a "harmless" label is refused if venomous species hold >5% probability; photos that do not look like snakes are rejected. Residual risk on the test set: 2 of 230 venomous photos were still accepted as harmless.
- Weaknesses: web photos (not field/clinical photos); only 13 species (Eryx johnii, Platyceps ventromaculatus, Telescopus rhinopoma are in the database but NOT in the model); cobras (N. naja vs N. kaouthia) and rat snake vs cobra are confused; several species are not native to Pakistan.
- `src/ml/classicalModels.ts` / `featureExtractor.ts` are the OLD untrained prototype classifier; they are kept only for the explanatory "28 descriptors" panel and legacy tests.
- Species text for the 8 newly added species (`src/data/speciesDataExtra.ts`) and the Sindhi translations are drafts: have a clinician / native speaker review them.
- Dose figures in the clinical engine must be verified against the national protocol before any real use.

Retraining: see `tools/train/README.md`.
